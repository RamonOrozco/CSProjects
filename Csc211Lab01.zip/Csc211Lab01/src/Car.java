/**
 * Name: Ramon
 * ID: 920516165
 * Class: CSC 211-01
 * Semester: Spring 2020
 */

public class Car extends Vehicle {
    private int wheels;
    private int doors;
    private int gears;
    private int currentGear;
    private boolean isAutomatic;

    Car  (String name, String size, int wheels, int doors, int gears, boolean isAutomatic){
        super(name, size);
        this.wheels = wheels;
        this.doors = doors;
        this.gears = gears;
        this.currentGear = 1;
        this.isAutomatic = isAutomatic;
    }

    public int getCurrentGear(){
        return this.currentGear;
    }

    public void changeGear(int currentGear){
        this.currentGear = currentGear;
    }
    public void changeVelocity(int velocity, int direction){
        move(velocity,direction);
    }
}
