/*Lab: 9
Description: TestTV
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */


public class TestTv {
    public static void main (String [] args ){
        //Calling up the methods and setting variables
        TV1 tv1 = new TV1 ();
        tv1.turnOn();
        tv1.setChannel(30);
        tv1.setVolume(3);

        //Calling up the methods and setting up more variables
        TV1 tv2 = new TV1();
        tv2.turnOn();
        tv2.channelUp();
        tv2.channelUp();
        tv2.volumeUp();

        //The print out statement displaying the channels on the TV and the volumes on each channel
        System.out.println("TV 1's channel is " + tv1.channel + " and volume level is " + tv1.volumeLevel);
        System.out.println("TV 2's channel is " + tv2.channel + " and volume level is " + tv2.volumeLevel);
    }
}

//class for TV1 that's located in the main method methods, with the data methods
class TV1 {
    int channel = 1;
    int volumeLevel = 1;
    boolean on = false;

    public TV1 (){

    }

    public void turnOn(){
        on = true;
    }

    public void turnoff(){
        on = false;
    }

    public void setChannel (int newChannel){
        if (on && newChannel >= 1 && newChannel <= 120){
            channel = newChannel;
        }
    }

    public void setVolume(int newVolumeLevel) {
        if (on && newVolumeLevel >= 1 && newVolumeLevel <= 7){
            volumeLevel = newVolumeLevel;
        }
    }
    public void channelUp(){
        if (on && channel < 120){
            channel++;
        }
    }
    public void channelDown(){
        if (on && channel > 1){
            channel--;
        }
    }
    public void volumeUp (){
        if (on && volumeLevel < 7){
            volumeLevel++;
        }
    }
    public void volumeDown(){
        if(on && volumeLevel > 1){
            volumeLevel--;
        }
    }
}