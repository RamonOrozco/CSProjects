/**
 * Name: Ramon
 * ID: 920516165
 * Class: CSC 211-01
 * Semester: Spring 2020
 */

public class Main {

    public static void main(String[] args) {

        System.out.println("Ramon ");
        System.out.println("");
        Outlander outlander = new Outlander();
        outlander.accelerate(50,30);
        outlander.changeGear(3);

        System.out.println("Car name : " + outlander.getName());
        System.out.println("Size is: " +outlander.getSize());
        System.out.println(outlander.getName() + " is facing in the direction of "
                + outlander.getCurrentDirection() + " degrees.");

        System.out.println(outlander.getName() + " is moving with the speed of "
                + outlander.getCurrentVelocity() + " and gear level is " + outlander.getCurrentGear() );
        System.out.println("Changing direction and stopping");
        outlander.stop();

        System.out.println(outlander.getName() + " is facing in the direction of " + outlander.getCurrentDirection() + " degrees.");
        System.out.println(outlander.getName() + " is moving with the speed of " + outlander.getCurrentVelocity() );

    }
}
