/*
Lab: 2
Description: BMI CALCULATOR
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */
import java.util.Scanner;
public class BMICalculator {
    public static void main (String[] args) {
        //The Scanner to pick up data
        Scanner sc = new Scanner (System.in);

        //Displaying welcoming message to the user
        System.out.print("BMI CALCULATOR ");
        System.out.println("Welcome, please input your height in METERS, and weight in KILOGRAMS. ");

        //Reading users height
        System.out.println("HEIGHT IN METERS: ");
        double height = sc.nextDouble();

        //Reading users weight
        System.out.println("WEIGHT IN KILOGRAMS: ");
        int weight = sc.nextInt();

        //Crunching the numbers
        double BMI = (weight / (height * height));
        int BMICasting = (int) BMI;

        //Displaying Users Height, Weight and BMI
        System.out.println("Your weight is:" + weight + " Meters");
        System.out.println("Your height is:" + height + " Kilograms");
        System.out.println("Your BMI is: " + BMI + "kg/m2");
        System.out.println("----------------------------------------");
        System.out.println("Your calculated BMI is:" +  BMICasting + "kg/m2");

    }
}
