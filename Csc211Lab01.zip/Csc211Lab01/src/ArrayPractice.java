/*Lab: 7
Description: Array Practice
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */
//importing the random util tool
import java.util.Random;
public class ArrayPractice {
    public static void main (String [] args) {
        //Part 1
        //Declaring an INT variable
        int a[] = new int[5];

        //Printing the second integer from the array "a"
        System.out.println(a[1]);

        //Setting the second integer from the array as 5
        a[1]=5;

        //Printing the second integer from the array "a"
        System.out.println(a[1]);

        //Printing the size of the array "a"
        System.out.println(a.length);

        //Part 2
        //Declaring the INT as b
        int b[]= new int[12];

        //Creating a for loop to set the integers values
        for (int i = 0; i <b.length ;i++){
            //Checking method to prevent an error on first integer
            if (i != 0){
                b[i] =  b[i - 1]+1;
            }
        }
        //Declaring a double
        double totalSum = 0;
        //Setting up the for loop
        for (int i = 0; i < b.length; i++){
            totalSum += b[i];
        }
        //Diving the totalSum by the size of b
        totalSum = totalSum/b.length;

        //Printing total sum
        System.out.println(totalSum);

        //PART 3
        //Declaring an int variable
        int c[] = new int[100];
        //inputting random class
        Random crandom = new Random();
        //Accessing the array to assign a random number to each position
        for (int i = 0; i <c.length; i++){
            c[i] = crandom.nextInt(101);
        }

        int maxvalue = 0;
        //Finding the greatest integer in c
        for (int i=0; i<c.length;i++){
            if (c[i] > maxvalue){
                maxvalue = c[i];
            }
        }
        //Printing greatest integer of c
        System.out.println(maxvalue);
    }
}
