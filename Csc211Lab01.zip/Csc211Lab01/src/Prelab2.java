import java.util.Scanner;
public class Prelab2 {
    public static void main(String[] args)
    {
        /*Assignment: Lab 1
        Description: Interactive user interface
        Name: Ramon Orozco
        ID: 920516165
        Class:CSC 210-04
        Semester: Spring 2020
         */
        System.out.println("Welcome to my program!");

        //Printing an int value
        System.out.println(100);

        //Printing an double value
        System.out.println(100.1);

        //Declaring a String variable
        String studentName;

        //Assigning a value to the String variable
        studentName = "Ada Lovelance";

        //Declaring an int variable
        int studentAge;

        //Assigning a value to an int variable
        studentAge = 12;

        /*
        Declaring a double variable and
        assigning a value in one line.
         */
        double studentGpa= 3.76;

        //Printing all variable values
        System.out.println(studentName);
        System.out.println(studentAge);
        System.out.println(studentGpa);

        //Present a question to the user
        System.out.print("What is your name? ");

        //Creating the Scanner object
        Scanner input = new Scanner (System.in);

        //Store the user input in a variable
        String userName = input.nextLine();

        //Print the user's name back to the display console
        System.out.print("The user's name is ");
        System.out.println(userName);
    }
}

