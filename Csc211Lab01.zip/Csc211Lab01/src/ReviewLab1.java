/*
Lab: ReviewLab1
Description: Review Lab
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */

import java.util.Scanner;
import java.util.Arrays;
public class ReviewLab1 {
    public static void main (String [] args){
        //PART 1

        //Inputting scanner class into project
        Scanner input = new Scanner(System.in);

        //Declaring height variable
        int height = 1;

        //Creating do while loop, which contains prompt for user input
        do{
            //Prompting user to input a value greater than one
            System.out.println("Hello, please input a desired number greater than 1 for the pyramids height: ");
            //Scanner for user input
            height = input.nextInt();
            //if statement for ERROR
            if (height <= 1){
                //Prompting user ERROR and to input new number
                System.out.println("Error, number is less than one, please try again");
            }
        }while(height <= 1);
        printPyramid(height);

        //Part 2
        //Setting the 2D arrays
        int columnSum= 0,rowSum= 0;
        //Setting up the arrays
        int [][] arrayOne = {{4, 7, 5, 3, 8}, {2, 6, 7, 1, 1,}, {4, 5, 9, 0, 2}};
        System.out.println(Arrays.deepToString(arrayOne).replace("],", "]\n").replace("[[", "[").replace("]]","]"));
        System.out.print("Sum of Rows: {");
        //nested for loop for the sums of the row
        for (int w = 0; w <arrayOne.length; w++){
            for (int y =0; y< arrayOne[0].length;y++){
                rowSum = rowSum +arrayOne[w][y];
            }
            System.out.print(rowSum +" ");
            rowSum =0;
        }
        System.out.println("}");
        //Prompting the sum of the Columns
        System.out.print("Sum of Columns: {");
        for (int q=0; q<arrayOne[0].length; q++){
            for (int s=0; s< arrayOne.length; s++){
                columnSum = columnSum + arrayOne [s][q];
            }
            System.out.print(columnSum + " ");
            columnSum = 0;
        }
        System.out.println("}");

        //PART 3
        //Setting up the 1D array
        int[] arrayTwo = {1,2,3,4,5,6,7};

        //Prompting user to input number of times to shift to the left
        System.out.println("How many times do you want to shift the number to the left?: ");
        //Grabbing th users input
        int shift = input.nextInt();
        System.out.println("Before: "+ Arrays.toString(arrayTwo));
        //Holding the original arrayTwo
        int[] temp = Arrays.copyOf(arrayTwo,arrayTwo.length);
        //Setting up the for loop statement to loop x amount of times
        for(int o=0; o < arrayTwo.length;o++){
            int offset = o-shift;
            if(offset< 0){
                offset = arrayTwo.length + offset;
            }
            arrayTwo[offset] = temp[o];
        }
        //Printing the after
        System.out.println("After: " +Arrays.toString(arrayTwo));
    }

//Creation of new method "printPyramid()"
    public static void printPyramid(int height){
        //For loop for the pyramid
        for(int i=1; i<height; i++){
            for (int j = height; j>=1; j--){
                if (j > i){
                    System.out.print(" ");
                }
                else {
                    System.out.print("* ");
                }
            }
            System.out.println();
        }
    }

}
