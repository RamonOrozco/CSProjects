/*
Lab: 6
Description: Method Practice
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */

public class MethodPractice {
    public static void main (String[] args){
        printHelloWorld();
        printHelloWorld();
        printHelloWorld();
        printInteger(5); System.out.println(" ");
        int a = addIntegers(5, 4);
        int b = addIntegers(12, 6);
        int c = addIntegers(a, b);
        System.out.println(c);
        printAddIntegers(10, 20);
        printAddIntegers(25, 4);
        System.out.println(isEven(4));
        System.out.println(isEven(11));
        System.out.println(isEven(addIntegers(5, 5)));
        System.out.println(linearFunction(5.0, 2.5, 0.0));
        System.out.println(linearFunction(1.0, 2.0, 3.0));
        System.out.println(linearFunction(15, 200, 5));



    }//End of main method

    //Creating the new method
    public static void printHelloWorld(){

        //Creating the for statement, and declaring the I to print statement 3 times
        for (int i=0; i<3; i++);

        System.out.println("Hello World!");
    }

    //Creating the new method
    public static void printInteger(int x){

        //For loop statement to print x Ten times
        for (int i=0; i<10; i++){
            System.out.print(x + " ");
        }
    }

    //Creating the new method part 2
    public static int addIntegers(int add1, int add2){
        //Calculating for the next method
        int sum =  add1 + add2;
        //Returning the sum of the new method
        return sum;
    }

    //Creating the new method
    public static void printAddIntegers(int add1, int add2){
        //Calling the addIntegers method by adding
        System.out.println(addIntegers(add1, add2));
    }

    //Creating the new method
    public static boolean isEven(int p){

        //Setting the boolean to return true if argument is even, while false if odd
        return p % 2 == 0;
    }
    //Representing the linear function in a method
    static double linearFunction(double x, double slope, double yIntercept) {
        //Returning method
        return (slope * x + yIntercept);
    }
}