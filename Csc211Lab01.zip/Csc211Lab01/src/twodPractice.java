/*
Lab: 2D Practice
Description: 2d Practice
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */

import java.util.Scanner;
import java.util.Arrays;
public class twodPractice {
    public static void main (String [] args){
        //Creating the Scanner Input
        Scanner input = new Scanner(System.in);


        //PART 1
        //Setting the character array with the elements
        char a[] = "happy".toCharArray();

        //Printing the elements in array a backwards
        for (int b = 4; b >= 0; b--){
            System.out.print(a[b]);
        }
        System.out.println(" ");
        //PART 2
        //Setting up the int 2d array
        int c[][] = new int[2][2];
        c[0][0] = 1;
        c[0][1] = 2;
        c[1][0] = 3;
        c[1][1] = 4;


        //declaring a int variable
        int Totalsum = 0;

        //Finding and printing the sum of the int elements inside the 2d arrays
        for (int d = 0; d < c.length; d++){//outer for loop (rows)
            for (int e=0; e < c[d].length;e++){//Inner for loop (columns)
                Totalsum += c[d][e];
            }
        }
        System.out.println("The Sum of all the numbers in th 2D array is " +Totalsum);
        //PART 3
        //Setting up the 2d int array
        int p[][] = new int[2][3];
        for (int i=0; i<p.length;i++){//outer for loop (rows)
            for (int m=0; m<p[i].length;m++){//Inner for loop (columns)
                System.out.println("Please input a number: ");
                p[i][m] = input.nextInt();
            }
        }
        //Totaling the sum of the 2D array p
        Totalsum = 0;
        for (int  z= 0;  z< p.length; z++){//outer for loop (rows)
            for (int r=0;  r< p[z].length;r++){//Inner for loop (columns)
                Totalsum += p[z][r];
            }
        }
        System.out.println("The Sum of the 2D Array is " + Totalsum);
        //PART 4
        //Setting up the int
        int [][] arrayFour = new int[4][3];
        for (int l=0;l<arrayFour.length;l++){
            for (int j=0;j<arrayFour[0].length;j++){
                arrayFour[l][j] = (int)(Math.random()*100);
            }
        }
        System.out.println(Arrays.deepToString(arrayFour).replace("],", "]\n").replace("[[", "[").replace("]]","]"));

        int max = arrayFour[0][0];
        for (int v =0;v<4;v++){
            for (int k=0; k<3;k++){
                if (arrayFour[v][k] > max){
                    max = arrayFour[v][k];
                }
            }
        }
        System.out.println("The Largest Element in the randomly generated 2D array is:  " + max);
    }
}
