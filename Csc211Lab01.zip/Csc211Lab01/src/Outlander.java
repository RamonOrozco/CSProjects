/**
 * Name: Ramon
 * ID: 920516165
 * Class: CSC 211-01
 * Semester: Spring 2020
 */

public class Outlander extends Car {

    Outlander(){
        super ("Outlander", "4WD",5,5,6,true);
    }

    public void accelerate(int rate, int direction){
        changeVelocity(rate, direction);
    }

}
