/*Lab: 5
Description: Fibonacci
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */

//Creating the Scanner class needed to create a Scanner

import java.util.Scanner;

public class Fibonacci {
    public static void main (String [] args) {

        //Creating the Scanner needed to pick up user input
        Scanner input = new Scanner(System.in);

        //Welcoming the user and prompting them to enter the desire amount wanted from the Fibonacci series
        System.out.println("Welcome user, please input the number of terms wanted from the Fibonacci series from 20 or less: " );

        //Creating a Int status to declare variables
        int x = 0;
        int y = 1;
        int h = 0;
        int user = input.nextInt();

        //Creating the IF statement to set the limit, in case the user inputs a number greater than 20, no executing the line of code
        if (user <= 20){
            //Giving the user the amount of numbers from the series based off their input
            System.out.print("The Fibonacci series is: " );

            //Inputting the while statement in order to execute the loop
            while (h <= user) {
                //Having print line in order to display the sequence from set number
                System.out.print(x + " ");

                //updating variables
                int z = x ;
                x = y;
                y = z + y;
                h++;
            }
        }
        else{
             //Display warning message to user
            System.out.println("The number you have entered is greater than 20, please enter a number lower or equal to 20.");
        }
    }
}
