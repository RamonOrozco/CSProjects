/*Lab: 6
Description: Library Practice
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */
import java.util.Scanner;
public class LibraryPractice {
    public static void main (String[] args){
        //PART ONE
        //Creating the first string
        String first = "\"Koalas are pretty cool!\" - William Lew";
        //Output for first string
        System.out.println(first);

        //Creating the second string line
        String second = first.replace(" ", "_");
        //Creating the output for second string
        System.out.println(second);

        //Creating the third string line
        String third = second.toUpperCase();
        //Creating the output for the third line
        System.out.println(third);

        //PART TWO
        //Creating the fourth string
        String fourth = "1!2@3#4$5%6^7&8*9(0)";
        //for each loop for the foruth string
        for (char yeet: fourth.toCharArray()
             ) {
            //if condition for the fourth string to not read the non digits
            if (!Character.isDigit(yeet)){
                //Printing the non digits from the fourth string
                System.out.println(yeet);
            }

        }
        //PART THREE
        //Creating the double called fifth
        double fifth = -1.23;
        //Absolute value of fifth
        System.out.println(Math.abs(fifth));
        //Value of fifth raised to power of 50
        System.out.println(Math.pow(fifth,50));
        //Square root of fifth
        System.out.println(Math.sqrt(fifth));
        //Doubled called sixth
        double sixth = 2.34;
        //Printing the max od fifth and sixth
        System.out.println(Math.max(fifth,sixth));
        //Printing the lowest of fifth and sixth
        System.out.println(Math.min(fifth,sixth));


    }
}
