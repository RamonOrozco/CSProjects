public class MyFirstLab {
    public static void main(String[] args) {
        /*Assignment: Lab 1
        Description: My First Lab
        Name: Ramon Orozco
        ID: 920516165
        Class:CSC 210-04
        Semester: Spring 2020
         */

        //Start the program by greeting the user.
        System.out.println("Hello World!");
        System.out.println("My name is Ramon Orozco.");

        //State that I'm an SFSU student on a single line.
        System.out.print("I am a ");
        System.out.print("student at ");
        System.out.println("SFSU");

        /*
        This is another set of print statements
        that states I'm an SFSU student,
        but it splits it on multiple lines.
         */
        System.out.println();
        System.out.println("I am a ");
        System.out.println("student at ");
        System.out.println("SFSU");
    }
}
