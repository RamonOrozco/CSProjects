/*Lab: 6
Description: prelab chapter 4
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */

//Creating the utility for the scanner
import java.util.Scanner;
public class Chapter4Prelab {
    public static void main (String[] args){

        //creating the scanner input for the program
        Scanner input = new Scanner (System.in);

        //Prompting user to enter a hex digit
        System.out.print("Enter a hex digit: ");

        //String line for the user input
        String hexString = input.nextLine();

        //Checking if the hex digit is exactly one character, not more
        if (hexString.length() !=1) {
            System.out.println("You mut enter exactly one character");
            System.exit(1);
        }

        //Displaying the user the value for their hex digit
        char ch = hexString.charAt(0);
        if (ch <= 'F' && ch >= 'A'){
            int value = ch - 'A' + 10;
            System.out.println("The decimal value for hex digit " + ch + " is " + value);
        }
        else if (Character.isDigit(ch)) {
            System.out.println("The decimal value for hex digit " + ch + " is " + ch);
        }
        else {
            System.out.println(ch + " is an invalid input");
        }

    }
}
