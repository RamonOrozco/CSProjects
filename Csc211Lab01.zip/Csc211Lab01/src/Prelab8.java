/*
Lab: prelab8
Description: prelab 8
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */


public class Prelab8 {
    public static void main (String [] args) {

        //the answers that students can use
        char [][] answer ={
                {'A','B','A','C','C','D','E','E','A','D'},
                {'D','B','A','B','C','A','E','E','A','D'},
                {'E','D','D','A','C','B','E','E','A','D'},
                {'C','B','A','E','D','C','E','E','A','D'},
                {'A','B','D','C','C','D','E','E','A','D'},
                {'B','B','E','C','C','D','E','E','A','D'},
                {'B','B','A','C','C','D','E','E','A','D'},
                {'E','B','E','C','C','D','E','E','A','D'}};


            //The Keys to the answers that are used
        char [] keys = {'D','B','D','C','C','D','A','E','A','D'};

        //Grade for all the answers
        for (int i=0; i< answer.length; i++) {
            //Grading one students grades
            int correctCount= 0;
            for (int j = 0; j < answer[i].length; j++){
                if (answer[i][j] ==  keys [j])
                    correctCount++;
            }

            //displaying the students grade
            System.out.println("Student " + i + " 's correct count is " + correctCount);
        }
    }
}
