/*Lab: 3
Description: GPA Calculator
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */

//importing a Scanner utility tool to pick up user input in the program
import java.util.Scanner;

public class GpaCalculator {
    public static void main(String[] args) {
        //Creating a Scanner in order to pick up user input
        Scanner input = new Scanner(System.in);

        //Welcome the user and explain to them whats happening in the program
        System.out.println("Welcome, today you'll be inputting your overall percentage to determine your " +
                "grade for the class.");

        //Tell user to now input their overall percentage to discover their grade for the class
        System.out.println("Now, please enter your overall percentage for the class: ");

        //Creating the double status in order
        double numbergrade = input.nextDouble();

        //Set up the guide for the GPA CALCULATOR
        String lettergrade = "";
        if (numbergrade >= 97) {
            lettergrade = "A+";
        }
        else if (numbergrade>= 93.0){
            lettergrade= "A";
        }
        else if (numbergrade>= 90.0){
            lettergrade= "A-";
        }
        else if (numbergrade>= 87.0){
            lettergrade= "B+";
        }
        else if (numbergrade>= 83.0){
            lettergrade= "B";
        }
        else if (numbergrade>= 80.0){
            lettergrade= "B-";
        }
        else if (numbergrade>= 77.0){
            lettergrade= "C+";
        }
        else if (numbergrade>= 70.0){
            lettergrade= "C";
        }
        else if (numbergrade>= 67.0){
            lettergrade= "D+";
        }
        else if (numbergrade>= 60.0){
            lettergrade= "D";
        }
        else if (numbergrade<= 60.0){
            lettergrade= "F";
        }
        //Setting up the GPA CHART by adding a doubling system
        double GPA = 0.0;
        //if and else if statements for the GPA CHART system that relies on the doubling
        if (lettergrade=="A+"){
            GPA=4.0;
        }
        else if (lettergrade=="A"){
            GPA=4.0;
        }
        else if (lettergrade=="A-"){
            GPA=3.7;
        }
        else if (lettergrade=="B+"){
            GPA=3.3;
        }
        else if (lettergrade=="B"){
            GPA=3.0;
        }
        else if (lettergrade=="B-"){
            GPA=2.7;
        }
        else if (lettergrade=="C+"){
            GPA=2.3;
        }
        else if (lettergrade=="C"){
            GPA=2.0;
        }
        else if (lettergrade=="D+"){
            GPA=1.7;
        }
        else if (lettergrade=="D"){
            GPA=1.0;
        }
        else if (lettergrade=="F"){
            GPA=0.1;
        }
        //Displaying the user their grade based off their input
        System.out.println("Your percentage is: " + numbergrade +
                "\nYour lettergrade is: " + lettergrade + "\nYour GPA is: " + GPA);
    }
}
