/*Lab: 2
Description: PRELAB 3
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */
import java.util.Scanner;

public class CaseStudyComputingTaxes {
    public static void main (String [] args) {
        //Creating A New Scanner Class For The Program
        Scanner input= new Scanner (System.in);

        //Prompt the user of the program to enter a status that their currently in
        System.out.print("0-single filer, 1-married jointly or" + "qualifying widow(er), 2-married separately, 3-head of"
        + "household) Enter the filing status: ");

        //Creating an int status
        int status = input.nextInt();

        //Tell the user to input their tax income into the system
        System.out.print("Enter the taxable income: ");
        double income = input.nextDouble();

        //Crunch the numbers
        double tax = 0;

        if (status == 0) { //Run numbers if the individual is single
            if (income <= 8350)
                tax = income * 0.10;
            else if (income <= 33950)
                tax = 8350 * 0.10 + (33950 - 8350) * 0.15 +
                        (income - 33950) * 0.25;
            else if (income <= 171550)
                tax = 8350 * 0.10 + (33950 - 8350) * 0.15 +
                        (82250 - 33950) * 0.25 + (income - 82250) * 0.28;
            else if (income <= 372950)
                tax = 8350 * 0.10 + (33950 - 8350) * 0.15 +
                        (82250 - 33950) * 0.25 + (171550 - 82250) * 0.28 +
                        (372950 - 171550) * 0.33 + (income - 372950) * 0.35;
        }
        else if (status == 1) { //Same as before, leave it as an memory tester
        }
        else if (status == 2) {//Same as before, leave it as an memory tester
        }
        else if (status == 3) {//Same as before, leave it as an memory tester
        }
        else {
            System.out.println("Error: invalid status");
            System.exit(1);
        }

        //Display the results from what the user has inputted
        System.out.println("Tax is " + (int)(tax * 100) / 100.0);
    }

}
