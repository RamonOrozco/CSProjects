/*Lab: 5
Description: Greatest Common Divisor Method
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */
//Creating the Scanner class for the project
import java.util.Scanner;

public class GreatestCommonDivisorMethod {

    public static void main(String [] args) {

        //Creating the Scanner in order to pick up the user input
        Scanner input = new Scanner(System.in);

        //Telling the user to input the two integers they'll be using
        System.out.print("Enter first integer: ");
        int n1 = input.nextInt();
        System.out.print("Enter second integer: ");
        int n2 = input.nextInt();

        //Telling the user what the greatest common divisor is for the two integers they wrote
        System.out.println("The greatest common divisor for " + n1 + " and " + n2 + " is " + gcd(n1,n2));
    }
     //Returning the gcd of the two integers that the user inputted into the system
    public static int gcd(int n1, int n2){
        int gcd = 1; //the initial gcd is 1
        int k = 2; //A possible gcd

        //the creating of a while statement
        while (k <= n1 && k <= n2){
            if (n1 % k == 0 && n2 % k == 0)
                gcd = k; //Updating the gcd value
            k++;
        }
        return gcd; //Returning the gcd to the user
    }
}
