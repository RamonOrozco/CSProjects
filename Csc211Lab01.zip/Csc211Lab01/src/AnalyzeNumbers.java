/*Lab: 7
Description: prelab 7
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */

public class AnalyzeNumbers {
    public static void main (String[] args) {

        //Creating the Scanner utility
        java.util.Scanner input = new java.util.Scanner(System.in);

        //Telling user to input number of items they have
        System.out.print("Enter the numbers of items: ");

        //Creating variables
        int n = input.nextInt();
        double[] numbers = new double[n];
        double sum = 0;


        //Telling user to enter the numbers
        System.out.print("Enter the numbers: ");

        //For statement
        for(int i = 0; i < n; i++){
            numbers [i] = input.nextDouble();
            sum+= numbers[i];
        }

        //Creating more variables for calculation
        double average = sum / n;

        int count = 0;  //Number of elements above average
        for (int i = 0; i<n; i++)
            if (numbers[i] > average)
                count++;

            //Creating the system output of end results
        System.out.println("Average is " + average);
        System.out.println("Number of elements above the average is " +count);
    }
}
