/*
Lab: prelab10
Description: prelab 10
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */

public class Prelab10 {
    public static void main (String [] args){

        //Creating the courses for the program
        Course course1= new Course ("Data Structures");
        Course course2 = new Course ("Data Systems");

        //Parts for course 1
        course1.addStudent("Peter Jones");
        course1.addStudent("Kim Smith");
        course1.addStudent("Anne Kennedy");

        //Parts for course 2
        course2.addStudent("Peter Jones");
        course2.addStudent("Steve Smith");

        //Printing the amount of  students in the council
        System.out.println("Number of students in course1: "+ course1.getNumberOfStudents());
        String[] students =course1.getStudents();
        for(int i = 0; i < course1.getNumberOfStudents();i++){
            System.out.print(students[i] + ", ");
        }

        System.out.println();
        System.out.print("Number of students in course2: " + course2.getNumberOfStudents());
    }
}


