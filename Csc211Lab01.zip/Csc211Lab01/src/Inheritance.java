public class Inheritance {

}
