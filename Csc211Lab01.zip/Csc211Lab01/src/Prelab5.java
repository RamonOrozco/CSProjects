/*Lab: 5
Description: PRELAB 5
Name: Ramon Orozco
ID: 920516165
Class: CSC 211-01
Semester: Spring 2020
 */

//Importing the java scanner tool

import java.util.Scanner;

public class Prelab5 {
    public static void main (String[] args){

        //Creating the Scanner input in order to detect user input
        Scanner input = new Scanner(System.in);

        //Telling the user to enter the two integers they wish to know
        System.out.print("Enter first integer: ");
        int n1 = input.nextInt();
        System.out.print("Enter second integer: ");
        int n2 = input.nextInt();

        int gcd = 1; //Stating the gcd as 1
        int k = 2; //Setting as potential gcd
        while (k <= n1 && k <= n2) {
            if (n1 % k == 0 && n2 % k == 0)
                gcd = k; //Updating the gcd
            k++;
        }
        System.out.println("The greatest common divisor for " + n1 +" and " + n2 + " is " + gcd);
    }
}

