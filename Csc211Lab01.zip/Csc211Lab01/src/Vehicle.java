/**
 * Name: Ramon
 * ID: 920516165
 * Class: CSC 211-01
 * Semester: Spring 2020
 */

public class Vehicle {
    private String name;
    private String size;
    private int currentVelocity;
    private int currentDirection;

    Vehicle (String name, String size){
        this.name = name;
        this.size = size;
        this.currentVelocity = 0;
        this.currentDirection = 0;
    }

    public String getName() {
        return this.name;
    }

    public String getSize(){
        return this.size;
    }

    public int getCurrentVelocity(){
        return this.currentVelocity;
    }

    public int getCurrentDirection(){
        return this.currentDirection;
    }
    public void stop(){
        this.currentVelocity = 0;
    }
    public void move(int velocity, int direction){
        this.currentVelocity = velocity;
        this.currentDirection = direction;
    }
}
